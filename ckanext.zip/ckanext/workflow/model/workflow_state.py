# encoding: utf-8

'''Model.'''

from __future__ import print_function
import sqlalchemy.orm as orm
import sqlalchemy.types as types
from ckan.model import meta, Package, DomainObject

from sqlalchemy import Table, Column, ForeignKey, Index, CheckConstraint, ForeignKeyConstraint, UniqueConstraint
# logging
import logging
log = logging.getLogger(__name__)

mapper = orm.mapper


class WorkflowState(DomainObject):

    package_id = None
    state_id = None
    _package = None
    _requests = None

    @property
    def package(self):
        """

        :return:
        """
        return self._package

    def __init__(self, package_id, state_id, **kwargs):
        super().__init__(**kwargs)
        self.package_id = package_id
        self.state_id = state_id

    @classmethod
    def all(cls):
        return meta.Session.query(cls).all()

    @classmethod
    def get(cls, package_id):
        """

        :param package_id:
        :return:
        """
        return meta.Session.query(cls).filter(cls.package_id == package_id).one_or_none()

    @classmethod
    def get_for_organization(cls, organization_id):
        query = meta.Session.query(cls)
        query = query.filter(cls._package.has(owner_org=organization_id))
        return query.all()


def define_workflow_state_table():
    workflow_state_table = Table(
        'workflow_state', meta.metadata,
        Column('package_id', types.UnicodeText, ForeignKey('package.id', ondelete="CASCADE"), primary_key=True),
        Column('state_id', types.UnicodeText, nullable=False),
        UniqueConstraint("package_id", "state_id"),
    )
    mapper(WorkflowState, workflow_state_table,
           properties={
               '_package': orm.relationship(Package, uselist=False)
           }, )
    return workflow_state_table
