'''API functions for deleting data from CKAN.'''

from ckanext.workflow.plugin.interfaces import IWorkflowRequestController
from ckan.plugins import PluginImplementations
# logging
import logging
log = logging.getLogger(__name__)

def workflow_request_delete(context, data_dict):
    """

    :param context:
    :param data_dict:
    """
    for plugin in PluginImplementations(IWorkflowRequestController):
        plugin.before_request_delete(context, data_dict)
    for plugin in PluginImplementations(IWorkflowRequestController):
        plugin.after_request_delete(context, data_dict)


def workflow_request_purge(context, data_dict):
    """

    :param context:
    :param data_dict:
    """
    for plugin in PluginImplementations(IWorkflowRequestController):
        plugin.before_request_purge(context, data_dict)
    for plugin in PluginImplementations(IWorkflowRequestController):
        plugin.after_request_purge(context, data_dict)
