from ckan.plugins import toolkit
from ckanext.workflow.helpers import _get_state
from ckan.logic.auth import get_package_object
import ckanext.workflow.constants as workflow_constants
import ckan.lib.plugins as lib_plugins
# logging
import logging
log = logging.getLogger(__name__)
tk_chained_auth_function = toolkit.chained_auth_function
tk_auth_sysadmins_check = toolkit.auth_sysadmins_check
tk_get_or_bust = toolkit.get_or_bust

# noinspection PyProtectedMember
tk__ = toolkit._
tk_get_action = toolkit.get_action

from ckan.plugins import toolkit


tk_chained_auth_function = toolkit.chained_auth_function
# noinspection PyProtectedMember
tk__ = toolkit._


@toolkit.auth_sysadmins_check
@toolkit.chained_auth_function
def package_update(original_action, context, data_dict):
    log.warning("chained_auth_function package_update data_dict_keys={}".format(
        len(data_dict.keys()) if data_dict is not None else None
    ))
    original_result = original_action(context, data_dict)
    original_success = original_result.get("success")
    if not original_success:
        log.warning("chained_auth_function package_update return original_result={}".format(original_result))
        return original_result

    pkg = get_package_object(context, data_dict)
    pkg_state = _get_state(pkg)
    user_id = context['auth_user_obj'].id
    update_allowed = pkg_state.update_allowed(context, user_id, pkg.id, pkg.owner_org)
    allowed_states = workflow_constants.WORKFLOW.allowed_states(context, pkg_state.id, user_id, pkg.id, pkg.owner_org, 'assign')

    if update_allowed and not allowed_states:
        allowed_states = [pkg_state.id]
    log.warning("chained_auth_function package_update update_allowed={} allowed_states={}".format(
        update_allowed, allowed_states
    ))

    if (data_dict is None and "package" in context) or list(data_dict.keys()) == ['id']:
        # check if either set_state or update is allowed
        if not (update_allowed or allowed_states):
            log.warning("chained_auth_function package_update not (update_allowed or allowed_states)")
            return {
                'success': False,
                'msg': 'not (update_allowed or allowed_states)'
            }
        return original_result
    else:
        package_plugin = lib_plugins.lookup_package_plugin(pkg.type)
        schema = context['schema'] if 'schema' in context else package_plugin.update_package_schema()
        data, errors = lib_plugins.plugin_validate(package_plugin, context, data_dict, schema, 'package_update')

        # if there are no errors
        if not errors:
            log.warning("no errors")
            is_update = True
            # remove the extras
            del data['extras']

            # convert the pkg into a dict and add the extras to make it easier to compare
            pkg_dict = dict(pkg.as_dict())
            log.warning("pkg")
            pkg_dict.update(pkg_dict.pop('extras', {}))

            changed_fields = set()
            set_keys = set(pkg_dict.keys()).union(set(data.keys())) - {'tag_string'}
            for key in set_keys:
                if key in pkg_dict and key not in data:
                    pass
                elif key not in pkg_dict and key in data:
                    # fields that are None will not be added as a PackageExtra so should be ignored when comparing
                    if data.get(key) is not None:
                        changed_fields.add(key)
                else:
                    if not (pkg_dict.get(key) == data.get(key)):
                        changed_fields.add(key)
            for key in changed_fields:
                log.warning("changed field: '{}': [{}] -> [{}]".format(
                    key, pkg_dict.get(key, 'NA'), data.get(key, 'NA')
                ))
            if workflow_constants.DEFAULT_FIELD in changed_fields:
                state = workflow_constants.WORKFLOW.get_state(data.get(workflow_constants.DEFAULT_FIELD))
                state_fields = {workflow_constants.DEFAULT_FIELD}
                if state.dataset_fields:
                    state_fields.update(set(state.dataset_fields.keys()))
                if not (changed_fields - state_fields):
                    is_update = False

            log.warning("no errors")
            log.warning("chained_auth_function package_update changed_fields={} is_update={}".format(
                changed_fields, is_update
            ))

            context["workflow_set_state"] = not is_update

            # check if either set_state or update is allowed based on data_dict
            if is_update and not update_allowed:
                log.warning("chained_auth_function package_update is_update and not update_allowed")
                return {
                    'success': False,
                    'msg': 'is_update and not update_allowed'
                }
            elif not is_update and not allowed_states:
                log.warning("chained_auth_function package_update not is_update and not allowed_states")
                return {
                    'success': False,
                    'msg': 'not is_update and not allowed_states'
                }

        return original_result

