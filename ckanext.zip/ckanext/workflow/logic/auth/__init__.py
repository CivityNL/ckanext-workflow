from ckan.plugins import toolkit
from ckanext.workflow.helpers import _get_state
from ckan.logic.auth import get_package_object

import ckanext.workflow.logic.auth.get as get
import ckanext.workflow.logic.auth.create as create
import ckanext.workflow.logic.auth.update as update
import ckanext.workflow.logic.auth.delete as delete
# logging
import logging
log = logging.getLogger(__name__)

tk_chained_auth_function = toolkit.chained_auth_function
# noinspection PyProtectedMember
tk__ = toolkit._


def workflow_update_allowed(action, getter, context, data_dict):
    """

    :param action:
    :param getter:
    :param context:
    :param data_dict:
    :return:
    """
    result = {}
    package_ids = getter(context, data_dict)
    if not package_ids:
        return result
    package_ids = package_ids if isinstance(package_ids, list) else [package_ids]
    for package_id in package_ids:
        pkg = get_package_object(context, {"id": package_id})
        user = context["user"]
        state = _get_state(pkg)
        success = state.update_allowed(context, user, pkg.id, pkg.owner_org)
        context["workflow_auth_checked"] = True
        result = {"success": success}
        if not success:
            user = context["user"]
            result['msg'] = tk__('[WORKFLOW] User %s not authorized to edit these packages') % user
            break
    return result


def workflow_chained_auth_function(action, getter):
    @tk_chained_auth_function
    def chained_auth_action(original_action, context, data_dict):
        log.warning("workflow_chained_auth_function for {}".format(action))
        original_result = original_action(context, data_dict)
        original_success = original_result.get("success")
        result = original_result
        log.warning("workflow_chained_auth_function for {} with workflow_auth_checked = {}".format(
            action, context.get('workflow_auth_checked', False))
        )
        if not original_success:
            result = original_result
        elif not context.get("workflow_auth_checked", False):
            update_allowed_result = workflow_update_allowed(action, getter, context, data_dict)
            if update_allowed_result:
                result = update_allowed_result
        return result

    return chained_auth_action
