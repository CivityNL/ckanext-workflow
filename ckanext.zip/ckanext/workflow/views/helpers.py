from ckan.plugins import toolkit
from ckan import model
# logging
import logging
log = logging.getLogger(__name__)

def get_context():
    return {'model': model, 'session': model.Session, 'user': toolkit.c.user, 'auth_user_obj': toolkit.c.userobj}