from ckanext.workflow.common import authz

##############################
# GENERIC
##############################

ROLE_PERMISSIONS = OrderedDict([
    ('admin', ['admin', 'membership']),
    ('editor', ['read', 'delete_dataset', 'create_dataset', 'update_dataset', 'manage_group']),
    ('member', ['read', 'manage_group']),
])

# return translated roles
def roles_trans():
    ''' return dict of roles with translation '''
    roles = {}
    for role in ROLE_PERMISSIONS:
        roles[role] = trans_role(role)
    return roles

##############################
# GROUPS/ORGANIZATIONS
##############################

# Used as validator in member_schema (for groups)
def role_exists(role, context):
    if role not in authz.ROLE_PERMISSIONS:
        raise Invalid(_('role does not exist.'))
    return role

# Used in:
# - member_roles_list: Return the possible roles for members of groups and organizations.
def roles_list():
    ''' returns list of roles for forms '''
    roles = []
    for role in ROLE_PERMISSIONS:
        roles.append(dict(text=trans_role(role), value=role))
    return roles


# returns the roles with the permission requested
# Used in:
# - has_user_permission_for_some_org: Check if the user has the given permission for any organization
# - group_list_authz: Return the list of groups that the user is authorized to edit.
# - organization_list_for_user: Return the organizations that the user has a given permission for
def get_roles_with_permission(permission):
    ''' returns the roles with the permission requested '''
    roles = []
    for role in ROLE_PERMISSIONS:
        permissions = ROLE_PERMISSIONS[role]
        if permission in permissions or 'admin' in permissions:
            roles.append(role)
    return roles


# Check if the user has the given permissions for the particular group (ignoring permissions cascading in a group hierarchy). Can also be filtered by a particular capacity.
# Used in:
# - has_user_permission_for_group_or_org: Check if the user has the given permissions for the group, allowing for sysadmin rights and permission cascading down a group hierarchy.
def _has_user_permission_for_groups(user_id, permission, group_ids,
                                    capacity=None):
    ''' Check if the user has the given permissions for the particular
    group (ignoring permissions cascading in a group hierarchy).
    Can also be filtered by a particular capacity.
    '''
    if not group_ids:
        return False
    # get any roles the user has for the group
    q = model.Session.query(model.Member) \
        .filter(model.Member.group_id.in_(group_ids)) \
        .filter(model.Member.table_name == 'user') \
        .filter(model.Member.state == 'active') \
        .filter(model.Member.table_id == user_id)
    if capacity:
        q = q.filter(model.Member.capacity == capacity)
    # see if any role has the required permission
    # admin permission allows anything for the group
    for row in q.all():
        perms = ROLE_PERMISSIONS.get(row.capacity, [])
        if 'admin' in perms or permission in perms:
            return True
    return False


##############################
# COLLABORATORS
##############################

def get_collaborator_capacities():
    if check_config_permission('allow_admin_collaborators'):
        return ('admin', 'editor', 'member')
    else:
        return ('editor', 'member')


